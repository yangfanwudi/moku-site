# 墨库 · 个人 Markdown 知识库与任务看板

单文件离线应用：**双击 `index.html`** 即可在 Chrome / Edge 中运行，无需安装、无需构建、无需本地服务器。

## 功能速览

- 📝 **知识库编辑（默认模式）**：左源码 / 右预览双栏，300ms 防抖实时渲染；支持 GFM 表格、任务列表、highlight.js 代码高亮、KaTeX 公式（`$...$` 与 `$$...$$`）；预览中的任务复选框可点击并反向回写源码；向编辑器粘贴截图自动转 base64 内嵌。
- 🗂️ **敏捷看板**：待办 / 进行中 / 已完成三泳道，卡片原生 HTML5 拖拽改状态（实时写库），点击卡片回到编辑模式。
- 🔍 **检索**：标题 + 全文实时搜索；标签云筛选（正文 `#标签` 中英文自动提取，也可手动添加 / 移除）。
- 💾 **持久化**：IndexedDB 本地存储（库名 `md-knowledge-base`，ObjectStore `notes`），所有变更 300ms 防抖自动保存，顶栏实时显示「保存中… / 已保存 HH:MM:SS」。
- 📦 **离线灾备**：
  - 导出 **JSON 快照**（全部笔记 + 元数据 + 导出时间）；
  - 导出 **ZIP 打包**（每篇一个独立 `.md`，slug 文件名 + YAML front-matter，附 `manifest.json`）；
  - 导入 JSON：校验结构后可选 **增量合并**（按 id 冲突时保留 `updated_at` 较新者）或 **全量覆盖**（单事务原子写入）。

## 数据说明

- 数据全部保存在浏览器本地 IndexedDB，**清空浏览器站点数据会丢失笔记**，请定期用顶栏 JSON / ZIP 按钮备份。
- 首次打开（库为空）会自动创建一篇「欢迎使用」示例笔记，演示各种语法。
- 依赖库（Vue 3 / Tailwind CSS / marked / highlight.js / KaTeX / JSZip）通过 CDN 加载：首次打开需联网，之后走浏览器缓存。

## 技术栈

Vue 3（Composition API） · Tailwind CSS · marked · highlight.js · KaTeX · JSZip · 原生 HTML5 Drag & Drop · IndexedDB
